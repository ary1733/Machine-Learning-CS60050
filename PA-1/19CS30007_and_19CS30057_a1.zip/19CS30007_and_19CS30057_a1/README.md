# INSTRUCTIONS

## Note

To run the assignment, keep Dataset_C.csv in the same directory as Q1.py and Q2.py

## Installation of dependencies

To install the dependencies, run the following command:

`pip install -r requirements.txt`

## Run the assignment

then run the python scripts using the following command

`python Q1.py`

and

`python Q2.py`
